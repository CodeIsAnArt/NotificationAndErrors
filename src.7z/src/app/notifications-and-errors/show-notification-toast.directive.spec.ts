import { ShowNotificationToastDirective } from './show-notification-toast.directive';

describe('ShowNotificationToastDirective', () => {
  it('should create an instance', () => {
    const directive = new ShowNotificationToastDirective();
    expect(directive).toBeTruthy();
  });
});
